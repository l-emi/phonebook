HOW TO INSTALL & RUN PROJECT
-----------------------------

1. Open your Command Prompt
2. Enter "npm install"
3. Enter "npm start"
4. Open your browser and go to http://localhost:8080/ 

Bingo!